import { configureStore } from '@reduxjs/toolkit'
import profileReducer from '../store/Features/ProfileSlice'
export const store = configureStore({
  reducer: {
    profile:profileReducer
  },
})
