import { createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
export interface UperProfileState {
    role: string
}
const initialState: UperProfileState = {
    role: 'Public',
}

export const profileSlice = createSlice({
    name: 'profile',
    initialState,
    reducers: {
      loginUser: (state) => {
        state.role = 'Admin'
      },
      logoutUser: (state) => {
        state.role = 'Public'
      },
    },
})
export const {loginUser,logoutUser} =profileSlice.actions;
export default profileSlice.reducer