export const environment = {
    production: true,
    appVersion: 'v1.0.00',
    apiUrl: 'https://apis.extsy.com/api/v1/en', // swagger api url goes here
    appThemeName: 'extsy',
    countryCodeUrl: 'https://gist.githubusercontent.com/anubhavshrimal/75f6183458db8c453306f93521e93d37/raw/f77e7598a8503f1f70528ae1cbf9f66755698a16/CountryCodes.json'
  };