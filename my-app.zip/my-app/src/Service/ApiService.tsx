
import { ApiResponse, ErrorCode } from "../Modals/response.model";
import { AxiosProgressEvent, AxiosRequestConfig } from 'axios';
import { environment } from '../Enviorments/environment';
import axios from 'axios';
import { getItem, StorageItem } from "../utils/local-storage.utils";
import { BehaviorSubject } from 'rxjs';


const headersConfig = {
    'LOCALE': 'en',
    'Accept': 'application/json',
    'access-control-allow-origin': '*'
  };

  const mediaProgress = new BehaviorSubject(0);
  export const mediaProgress$ = mediaProgress.asObservable();
export class ApiService<T> {

    private setHeaders(): any {
        const header = {
          ...headersConfig,
          'Content-Type': 'application/json',
        };
        return header;
    }

    get JwtToken(): string {
        return getItem(StorageItem.JwtToken)?.toString() || '';
    }

    get FirebaseToken(): string {
        return getItem(StorageItem.FirebaseToken)?.toString() || ''
    }

    private setFBHeaders(): any {
        const header = {
          ...headersConfig,
          'Content-Type': 'application/json',
          'Authorization': `${this.FirebaseToken}`
        };
        return header;
    }

    get currentUser(): any {
        return getItem(StorageItem.User) || {};
    }

    private objectToQueryString(obj: any): string {
        const str = [];
        for (const p in obj)
          if (obj.hasOwnProperty(p)) {
            str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
          }
        return str.join('&');
    }

    private async handleResponse<TData>(response: any): Promise<ApiResponse<TData>> {
        const result = new ApiResponse<TData>();
        return response.then((res: any) => {
            if([200, 201, 204].includes(res.status)) {
                delete res.config
                delete res.request
                delete res.statusText
                res.status = true;
                delete res.headers
                delete result.headers
                Object.assign(result, res);
                return result;
            }
        })
        .catch((error: any) => {
            if(error) {
                if ([401, 403].includes(error.response.status)) {
                    // auto logout if 401 Unauthorized or 403 Forbidden response returned from api. No need for error interceptor
                    // logout user function call
                }
                const result = new ApiResponse<TData>();
                if (
                    error instanceof ErrorEvent ||
                    error instanceof ProgressEvent
                ) {
                    result.errors.push({
                        code: ErrorCode.UnknownError,
                        text: 'Unknown error.'
                    });
                }
                else {
                    result.errors.push({
                        code: error.code,
                        text: error.response.statusText,
                        error: error.response.status
                    });
                }
                return result;
            }
        })
        // return result;
    }

    public async get(path: string,params?: any): Promise<ApiResponse<T>>
     {
        const options: AxiosRequestConfig = {
            method: 'GET',
            params: params,
            headers: this.setHeaders()
        }
        return await this.handleResponse<T>(axios.get<ApiResponse<T>>(`${environment.apiUrl}${path}`, options))
    }

    
    public async post(path: string, body: Object = {}): Promise<ApiResponse<T>> {
        const options: AxiosRequestConfig = {
            method: 'POST',
            headers: this.setHeaders()
        }
        return await this.handleResponse<T>(axios.post<ApiResponse<T>>(`${environment.apiUrl}${path}`, JSON.stringify(body), options))
    }

    public async firebasePost(
        path: string,
        body: Object = {}
    ): Promise<ApiResponse<T>> {
        const options: AxiosRequestConfig = {
            method: 'POST',
            headers: this.setFBHeaders()
        }
        return await this.handleResponse<T>(axios.post<ApiResponse<T>>(`${environment.apiUrl}${path}`, JSON.stringify(body), options))
    }

    public async put(
        path: string,
        body: Object = {}
    ): Promise<ApiResponse<T>> {
        const options: AxiosRequestConfig = {
            method: 'PUT',
            headers: this.setHeaders()
        }
        return await this.handleResponse<T>(axios.put<ApiResponse<T>>(`${environment.apiUrl}${path}`, JSON.stringify(body), options))
    }

    public async delete(
        path: string,
        body: Object = {}
    ): Promise<ApiResponse<T>> {
        const options: AxiosRequestConfig = {
            method: 'DELETE',
            headers: this.setHeaders(),
            data: JSON.stringify(body)
        }
        return await this.handleResponse<T>(axios.delete<ApiResponse<T>>(`${environment.apiUrl}${path}`, options))
    }

    public async postMedia(
        path: string,
        body: any = {}
      ): Promise<ApiResponse<T>> {
        return await this.handleResponse<T>(axios.post<ApiResponse<T>>(`${environment.apiUrl}${path}`, body));
    }

    public async postMediaWithProgress(
        path: string,
        body: any = {}
      ): Promise<ApiResponse<T>> {
        return await this.handleResponse<T>(axios.post<ApiResponse<T>>(`${environment.apiUrl}${path}`, body,
        {
            onUploadProgress: (progressEvent: AxiosProgressEvent | any) => {
                let percentComplete = progressEvent.loaded / progressEvent.total;
                percentComplete = percentComplete * 100;
                mediaProgress.next(percentComplete);
            }
        }));
    }

}